package version

// Version information (set during build)
var (
	Version   = "dev"
	GitCommit = "none"
	BuildDate = "unknown"
)
