// Copyright The OpenTelemetry Authors
// Licensed under the Apache License, Version 2.0

package simplereceiver

import (
	"context"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/receiver"
)

const (
	// TypeStr is the unique identifier for the Simple receiver.
	typeStr = "simplereceiver"

	// Default endpoints to bind to.
	defaultEndpoint = ":4317"
)

// NewFactory creates a factory for Simple receiver.
func NewFactory() receiver.Factory {
	return receiver.NewFactory(
		component.Type(typeStr),
		createDefaultConfig,
		receiver.WithTraces(createTracesReceiver, component.StabilityLevelAlpha),
		receiver.WithMetrics(createMetricsReceiver, component.StabilityLevelAlpha),
		receiver.WithLogs(createLogsReceiver, component.StabilityLevelAlpha),
	)
}

func createDefaultConfig() component.Config {
	return &Config{
		Endpoint: defaultEndpoint,
	}
}

func createTracesReceiver(
	_ context.Context,
	set component.CreateSettings,
	cfg component.Config,
	nextConsumer consumer.Traces,
) (receiver.Traces, error) {
	rCfg := cfg.(*Config)
	return newReceiver(rCfg, set.TelemetrySettings, nextConsumer)
}

func createMetricsReceiver(
	_ context.Context,
	set component.CreateSettings,
	cfg component.Config,
	nextConsumer consumer.Metrics,
) (receiver.Metrics, error) {
	rCfg := cfg.(*Config)
	return newReceiver(rCfg, set.TelemetrySettings, nextConsumer)
}

func createLogsReceiver(
	_ context.Context,
	set component.CreateSettings,
	cfg component.Config,
	nextConsumer consumer.Logs,
) (receiver.Logs, error) {
	rCfg := cfg.(*Config)
	return newReceiver(rCfg, set.TelemetrySettings, nextConsumer)
}
