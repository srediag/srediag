// Copyright The OpenTelemetry Authors
// Licensed under the Apache License, Version 2.0

package simplereceiver

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"sync"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.uber.org/zap"
)

type simpleReceiver struct {
	config   *Config
	server   *http.Server
	wg       sync.WaitGroup
	settings component.TelemetrySettings

	// Consumers for different signal types
	nextConsumer interface{} // can be consumer.Traces, consumer.Metrics, or consumer.Logs
}

func newReceiver(config *Config, settings component.TelemetrySettings, nextConsumer interface{}) (*simpleReceiver, error) {
	r := &simpleReceiver{
		config:       config,
		settings:     settings,
		nextConsumer: nextConsumer,
	}

	return r, nil
}

// Start implements component.Component
func (r *simpleReceiver) Start(ctx context.Context, host component.Host) error {
	r.settings.Logger.Info("Starting simple receiver",
		zap.String("endpoint", r.config.Endpoint))

	var err error
	var listener net.Listener

	listener, err = net.Listen("tcp", r.config.Endpoint)
	if err != nil {
		return fmt.Errorf("failed to bind to address %s: %w", r.config.Endpoint, err)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/v1/traces", r.handleTraces)
	mux.HandleFunc("/v1/metrics", r.handleMetrics)
	mux.HandleFunc("/v1/logs", r.handleLogs)

	r.server = &http.Server{
		Handler: mux,
	}

	r.wg.Add(1)
	go func() {
		defer r.wg.Done()
		if err := r.server.Serve(listener); err != http.ErrServerClosed {
			r.settings.Logger.Error("Server error", zap.Error(err))
		}
	}()

	return nil
}

// Shutdown implements component.Component
func (r *simpleReceiver) Shutdown(ctx context.Context) error {
	if r.server != nil {
		err := r.server.Shutdown(ctx)
		r.wg.Wait()
		return err
	}
	return nil
}

func (r *simpleReceiver) handleTraces(w http.ResponseWriter, req *http.Request) {
	consumer, ok := r.nextConsumer.(consumer.Traces)
	if !ok {
		http.Error(w, "Traces consumer not configured", http.StatusInternalServerError)
		return
	}

	// Create empty traces data for demonstration
	traces := ptrace.NewTraces()
	err := consumer.ConsumeTraces(req.Context(), traces)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func (r *simpleReceiver) handleMetrics(w http.ResponseWriter, req *http.Request) {
	consumer, ok := r.nextConsumer.(consumer.Metrics)
	if !ok {
		http.Error(w, "Metrics consumer not configured", http.StatusInternalServerError)
		return
	}

	// Create empty metrics data for demonstration
	metrics := pmetric.NewMetrics()
	err := consumer.ConsumeMetrics(req.Context(), metrics)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func (r *simpleReceiver) handleLogs(w http.ResponseWriter, req *http.Request) {
	consumer, ok := r.nextConsumer.(consumer.Logs)
	if !ok {
		http.Error(w, "Logs consumer not configured", http.StatusInternalServerError)
		return
	}

	// Create empty logs data for demonstration
	logs := plog.NewLogs()
	err := consumer.ConsumeLogs(req.Context(), logs)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}
