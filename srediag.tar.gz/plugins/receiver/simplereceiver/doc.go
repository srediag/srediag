// Copyright The OpenTelemetry Authors
// Licensed under the Apache License, Version 2.0

// Package simplereceiver implements a simple receiver that can be used as a template
// for creating new receivers.
package simplereceiver // import "github.com/srediag/srediag/plugins/receiver/simplereceiver"
