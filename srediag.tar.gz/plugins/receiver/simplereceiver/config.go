// Copyright The OpenTelemetry Authors
// Licensed under the Apache License, Version 2.0

package simplereceiver

import (
	"errors"
	"fmt"
	"net"

	"go.opentelemetry.io/collector/component"
)

// Config defines configuration for the Simple receiver.
type Config struct {
	// Endpoint configures the listening endpoint for the receiver.
	// The valid syntax is described at https://github.com/grpc/grpc/blob/master/doc/naming.md.
	// For TCP and localhost:1234 or :1234 are valid.
	Endpoint string `mapstructure:"endpoint"`
}

var _ component.Config = (*Config)(nil)

// Validate checks if the receiver configuration is valid
func (cfg *Config) Validate() error {
	if cfg.Endpoint == "" {
		return errors.New("endpoint must be specified")
	}

	if _, _, err := net.SplitHostPort(cfg.Endpoint); err != nil {
		return fmt.Errorf("endpoint is not a valid host:port pair: %w", err)
	}

	return nil
}
