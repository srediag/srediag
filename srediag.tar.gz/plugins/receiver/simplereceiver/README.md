# Simple Receiver

The Simple receiver is a template receiver that can be used as a starting point for creating new receivers.

## Configuration

The following settings are required:

- `endpoint` (default: ":4317"): The address to listen on.

Example:

```yaml
receivers:
  simplereceiver:
    endpoint: localhost:4317

service:
  pipelines:
    traces:
      receivers: [simplereceiver]
      processors: []
      exporters: [otlp]
    metrics:
      receivers: [simplereceiver]
      processors: []
      exporters: [otlp]
    logs:
      receivers: [simplereceiver]
      processors: []
      exporters: [otlp]
```

The full list of settings exposed for this receiver are documented [here](./config.go)
with detailed sample configurations [here](./testdata/config.yaml).

## Stability Level

This receiver is in alpha stage. It may change in backward incompatible ways and is not recommended for production environments.
